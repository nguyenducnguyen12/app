import customtkinter as ctk
import os,json,matplotlib,openpyxl,pandas,xlrd,webbrowser,sys,shutil
from PIL import Image, ImageTk
import tkinter.filedialog as filedialog
from tkinter import messagebox
class Pyqm:
    def __init__(fr, file_path):
        fr.file_path = file_path
        fr.data = {}
    def compile(fr):
        with open("Resouces\\Settinngs\\Langjs\\chosserlang.json", 'r', encoding="UTF-8") as file:
            settings = json.load(file)
        language = settings["language"]
        qm_file = f"Resouces//Language//{language}.qm"

        if not os.path.isfile(qm_file):
            qm_file = "Resouces//Language/VIE.QM"
        with open(qm_file, 'r', encoding="UTF-8") as file:
            lines = file.readlines()
        for line in lines:
            if line.startswith('#'):
                continue
            index = line.find('=')
            if index != -1:
                key = line[:index].strip().lower()
                value = line[index + 1:].strip()
                fr.data[key] = value
    def translate(root1, key):
        return root1.data.get(key.lower())
pyqm = Pyqm('Resouces//Language//VIE.QM')
pyqm.compile()
app=ctk.CTk()
app.title(pyqm.translate("Account"))
app.iconbitmap("Resouces\\Image\\ico\\app.ico")
app.geometry("900x500")
root1=ctk.CTk()
root1.geometry("900x500")
root1.iconbitmap("Resouces\\Image\\ico\\app.ico")
root1.title(pyqm.translate("MAIN_APP_NAME_TITLE"))
root1.configure(fg_color="#F9FBE7")
app.configure(fg_color="#F9FBE7")
app.resizable(False,False)
root1.resizable(False,False)
root2=ctk.CTk()
root2.geometry("900x500")
root2.iconbitmap("Resouces\\Image\\ico\\app.ico")
root2.resizable(False,False)
root2.title(pyqm.translate("Settings"))
root2.configure(fg_color="#F9FBE7")
def wr1():
    app.withdraw()
    root1.deiconify()
    root2.withdraw()
def wr2():
    app.deiconify()
    root1.withdraw()
    root2.withdraw()
def wr3():
    app.withdraw()
    root1.withdraw()
    root2.deiconify()
def exit_app():
    app.destroy()
    root1.destroy()
    root2.destroy()
app.protocol("WM_DELETE_WINDOW", exit_app)
root1.protocol("WM_DELETE_WINDOW", exit_app)
root2.protocol("WM_DELETE_WINDOW", exit_app)
#color_and_chooser
with open("Resouces\\Settinngs\\Colorjs\\Button.json") as bt:
    but=json.load(bt)
with open("Resouces\\Settinngs\\Colorjs\\color.json",'r') as bt:
    color=json.load(bt)
frame1_color=color[1]["Frame"]["FrameControl"]
frame2_color=color[1]["Frame"]["Frame_Broad"]
button_color=color[0]["Button"]["Button_color"]
button_hover_color=color[0]["Button"]["button_hover_color"]
border_color=color[0]["Button"]["border_color"]
dropdown_fg_color=color[0]["Button"]["dropdown_fg_color"]
with open("Resouces\\Settinngs\\Colorjs\\Button.json",'r') as bt:
    bt1=json.load(bt)
button_fg=bt1["button_fg"]
hover_color=bt1["hover_color"]
#frame
frame1=ctk.CTkFrame(app,fg_color=frame1_color,width=100,height=1000)
frame1.place(x=0,y=0)
frame2=ctk.CTkFrame(root1,fg_color=frame1_color,width=100,height=1000)
frame2.place(x=0,y=0)
frame3=ctk.CTkFrame(root2,fg_color=frame1_color,width=100,height=1000)
frame3.place(x=0,y=0)
"""taskbar"""
button1_taskbar1=ctk.CTkButton(frame1,text=pyqm.translate("Account"),fg_color=button_fg,hover_color=hover_color,width=15,text_color="white",command=wr2)
button1_taskbar1.place(x=0,y=20)
button1_taskbar2=ctk.CTkButton(frame1,text=pyqm.translate("Management_button"),fg_color=button_fg,hover_color=hover_color,width=15,text_color="white", command=wr1)
button1_taskbar2.place(x=0,y=50)
button1_taskbar3=ctk.CTkButton(frame1,text=pyqm.translate('settings'),fg_color=button_fg,hover_color=hover_color,width=15,text_color="white",command=wr3)
button1_taskbar3.place(x=0,y=80)
button2_taskbar1=ctk.CTkButton(frame2,text=pyqm.translate("Account"),fg_color=button_fg,hover_color=hover_color,width=15,text_color="white",command=wr2)
button2_taskbar1.place(x=0,y=20)
button2_taskbar2=ctk.CTkButton(frame2,text=pyqm.translate("Management_button"),fg_color=button_fg,hover_color=hover_color,width=15,text_color="white",command=wr1)
button2_taskbar2.place(x=0,y=50)
button2_taskbar3=ctk.CTkButton(frame2,text=pyqm.translate('settings'),fg_color=button_fg,hover_color=hover_color,width=15,text_color="white",command=wr3)
button2_taskbar3.place(x=0,y=80)
button3_taskbar1=ctk.CTkButton(frame3,text=pyqm.translate("Account"),fg_color=button_fg,hover_color=hover_color,width=15,text_color="white",command=wr2)
button3_taskbar1.place(x=0,y=20)
button3_taskbar2=ctk.CTkButton(frame3,text=pyqm.translate("Management_button"),fg_color=button_fg,hover_color=hover_color,width=15,text_color="white",command=wr1)
button3_taskbar2.place(x=0,y=50)
button3_taskbar3=ctk.CTkButton(frame3,text=pyqm.translate('settings'),fg_color=button_fg,hover_color=hover_color,width=15,text_color="white",command=wr3)
button3_taskbar3.place(x=0,y=80)
#taikhoan
#taikhoan
#ham

radio_var= ctk.IntVar(value=0)
def select_pic():
    pass
def choose_button():
    a=radio_var.get()
    if a==1:
        with open("Database\\data\\app\\1.json",'w') as f:
            settings={"select":"no"}
            json.dump(settings,f)
    elif a==2:
        with open("Database\\data\\app\\1.json",'w') as f:
            settings={"select":"yes"}
            json.dump(settings,f)
def auto_select():
    global radio_var
    with open("Database\\data\\app\\1.json",'r') as f:
        a=json.load(f)
    b=a["select"]
    if b=="yes":
        radio_var.set(2)
    else:   
        radio_var.set(1)
        
auto_select()
def change_picture():
    # Mở hộp thoại để người dùng chọn file ảnh mới
    filepath = filedialog.askopenfilename(initialdir="/", title="Select Image", filetypes=(("Image files", "*.png *.jpg *.jpeg"), ("All files", "*.*")))
    if filepath:
        try:
            filename = os.path.basename(filepath)
            new_filepath = os.path.join("Resouces//Image//png", filename)
            if not os.path.exists(new_filepath):
                shutil.copy2(filepath, new_filepath)
            
            # Lưu đường dẫn vào tệp png.json
            with open("Resouces//Image//png//png.json", 'w') as f:
                settings = {"path": new_filepath}
                json.dump(settings, f)
                messagebox.showinfo("xxxx",'xxxxx')
            
        except IOError:
            messagebox.showerror("Error", "Failed to open image file.")
#widget
label_name=ctk.CTkLabel(app,text=pyqm.translate("Account"),fg_color="#F9FBE7",font=("Arial",16))
label_name.pack()
with open("Database\\data\\app\\save.json",'r',encoding="UTF-8") as dt:
    data=json.load(dt)
name_pl=data["name"]
age_pl=data["age"]
place_pl=data["place"]
class_pl= data["class"]
school_pl=data["school"]
with open("Resouces\\Image\\png\\png.json",'r') as f:
    img=json.load(f)
imgage=img["path"]
my_image = ctk.CTkImage( Image.open(imgage),size=(130, 130))
img=ctk.CTkButton(app,image=my_image,text="",fg_color="#F9FBE7",hover_color="#F9FBE7",command=change_picture).pack(pady=2)
ifmt=ctk.CTkLabel(app,text=pyqm.translate("info"))
ifmt.pack()
fr=ctk.CTkFrame(app,width=700,height=270,fg_color="#99ff99")
fr.place(x=140,y=210)
name=ctk.CTkLabel(fr,text=pyqm.translate("name"),font=("arial",15))
name.place(x=10,y=20)
entry_name=ctk.CTkEntry(fr,placeholder_text=name_pl,placeholder_text_color="black")
entry_name.place(x=90,y=20)
age=ctk.CTkLabel(fr,text=pyqm.translate("age"),font=("arial",15))
age.place(x=10,y=90)
entry_age=ctk.CTkEntry(fr,placeholder_text=age_pl,placeholder_text_color="black")
entry_age.place(x=90,y=90)
place=ctk.CTkLabel(fr,text=pyqm.translate("place"),font=("ARIAL",15))
place.place(x=10,y=160)
entry_place=ctk.CTkEntry(fr,placeholder_text=place_pl,placeholder_text_color="black")
entry_place.place(x=90,y=160)
lop=ctk.CTkLabel(fr,text=pyqm.translate("class"),font=("Arial",15))
lop.place(x=390,y=20)
entry_lop=ctk.CTkEntry(fr,placeholder_text=class_pl,placeholder_text_color="black")
entry_lop.place(x=460,y=20)
school=ctk.CTkLabel(fr,text=pyqm.translate("school"),font=("arial",15))
school.place(x=390,y=90)
entry_school=ctk.CTkEntry(fr,placeholder_text=school_pl,placeholder_text_color="black")
entry_school.place(x=460,y=90)
birthday=ctk.CTkLabel(fr,text=pyqm.translate("msgbox"),font=("arial",13))
birthday.place(x=390,y=160)

radiobutton_1 = ctk.CTkRadioButton(fr, text="No", command= choose_button,variable= radio_var, value=1)
radiobutton_1.place(x=480,y=160)
radiobutton_2 = ctk.CTkRadioButton(fr, text="Yes",command=choose_button, variable= radio_var, value=2)
radiobutton_2.place(x=550,y=160)
#caidat
Label=ctk.CTkLabel(root2,text=pyqm.translate("settings"),fg_color="#F9FBE7",font=("arial",15))
Label.pack()

app.mainloop()