import customtkinter as ctk
import os,json,webbrowser,sys
from tkinter import messagebox
class Pyqm:
    def __init__(self, file_path):
        self.file_path = file_path
        self.data = {}
    def compile(self):
        with open("Resouces\\Settinngs\\Langjs\\chosserlang.json", 'r', encoding="UTF-8") as file:
            settings = json.load(file)
        language = settings["language"]
        qm_file = f"Resouces//Language//{language}.qm"
        if not os.path.isfile(qm_file):
            qm_file = "Resouces//Language/VIE.QM"
        with open(qm_file, 'r', encoding="UTF-8") as file:
            lines = file.readlines()
        for line in lines:
            if line.startswith('#'):
                continue
            index = line.find('=')
            if index != -1:
                key = line[:index].strip().lower()
                value = line[index + 1:].strip()
                self.data[key] = value
    def translate(root1, key):
        return root1.data.get(key.lower())
pyqm = Pyqm('Resouces//Language//VIE.QM')
pyqm.compile()
main=ctk.CTk()
main.title(pyqm.translate("CONTROL_PANE_APP_TITLE"))
main.iconbitmap("Resouces//Image//ico//app1.ico")
main.resizable(False,False)
main.configure(fg_color="#C6FFF6")
main.geometry("550x380")
#Đọc Tệp
with open("Resouces\\Settinngs\\Langjs\\value.json",'r') as f:
    vl=json.load(f)
with open("Resouces\\Settinngs\\Colorjs\\color.json",'r') as bt:
    color=json.load(bt)
value=vl["value"]
frame1_color=color[1]["Frame"]["FrameControl"]
frame2_color=color[1]["Frame"]["Frame_Broad"]
button_color=color[0]["Button"]["Button_color"]
button_hover_color=color[0]["Button"]["button_hover_color"]
border_color=color[0]["Button"]["border_color"]
dropdown_fg_color=color[0]["Button"]["dropdown_fg_color"]
ex1=color[0]["Button"]["Button_blue"]
ex2=color[0]["Button"]["Button_green"]
ex3=color[0]["Button"]["Button_dark_blue"]
value1=[pyqm.translate("SELECT_VALUES_BUTTON"),pyqm.translate("value_button1"),pyqm.translate("value_button2"),pyqm.translate("value_button3")]
with open("Resouces\\Settinngs\\Colorjs\\Button.json",'r') as bt:
    bt1=json.load(bt)
button_fg=bt1["button_fg"]
hover_color=bt1["hover_color"]
##Hàm
def xacnhan():
    a=cbb.get()
    if a=="English":
        with open("Resouces\\Settinngs\\Langjs\\chosserlang.json",'w') as f:
            settings={"language":'en'}
            json.dump(settings,f)
        with open("Resouces\\Settinngs\\Langjs\\value.json",'w') as fl:
            new_vl={"value": ["English", "Ti\u1ebfng Vi\u1ec7t"]}
            json.dump(new_vl,fl)
    elif a=="Tiếng Việt":
        with open("Resouces\\Settinngs\\Langjs\\chosserlang.json",'w') as f:
            settings={"language":'vie'}
            json.dump(settings,f)
        with open("Resouces\\Settinngs\\Langjs\\value.json",'w') as fl:
            new_vl={"value": [ "Ti\u1ebfng Vi\u1ec7t","English"]}
            json.dump(new_vl,fl)
    b=cbb1.get()
    if b==pyqm.translate("Value_button1"):
        with open("Resouces\\Settinngs\\Colorjs\\Button.json",'w') as fl1:
            cl={"button_fg":"#3B8ED1","hover_color":"#4775d1"}
            json.dump(cl,fl1)
    elif b==pyqm.translate("Value_button2"):
         with open("Resouces\\Settinngs\\Colorjs\\Button.json",'w') as fl1:
            cl={"button_fg":"#3E7BBB","hover_color":"#004080"}
            json.dump(cl,fl1)
    elif b==pyqm.translate("Value_button3"):
         with open("Resouces\\Settinngs\\Colorjs\\Button.json",'w') as fl1:
            cl={"button_fg":"#27CB84","hover_color":"#00cc44"}
            json.dump(cl,fl1)
        
            
        
def  reset():
    msg=messagebox.askquestion(pyqm.translate("info"),pyqm.translate("reset_ques"))
    if msg=="no":
        messagebox.showinfo(pyqm.translate('info'),pyqm.translate("reset_cancel"))
    else:
        with open("Resouces\\Settinngs\\Langjs\\value.json","w") as f1:
            settings={"value": [ "Ti\u1ebfng Vi\u1ec7t","English"]}
            json.dump(settings,f1)
        with open("Resouces\\Settinngs\\Colorjs\\color.json","w") as f2:
            settings1=[
  {
    "Button": {
      "Button_green": "#27CB84",
      "Button_blue": "#3B8ED1",
      "Button_dark_blue": "#3E7BBB",
      "button_hover_color": "pink",
      "Button_color": "Pink",
      "border_color": "white",
      "dropdown_fg_color":"pink"
    }
  },
  {
    "Frame": {
      "FrameControl": "lightblue",
      "Frame_Broad": "lightgreen"
    }
  }
]

            json.dump(settings1,f2)
        with open("Resouces//Settings\\a3\\a1.json","w") as f3:
            se={"button_fg": "#3B8ED1", "hover_color": "#4775d1"}
            json.dump(se,f3)
        with open("Resouces//settings//a1//st-lg.json","w") as f4:
            sq={"language": "vie"}
            json.dump(sq,f4)
def checkupdate():
    pass
def update():
    pass
def color_settings():
    try:
        os.startfile("debug.exe")
    except:
        messagebox.showerror("Không tìm thấy")
def contact(event):
    webbrowser.open("https://facebook.com//nguyen30112007")

#widget
Label1=ctk.CTkLabel(main,text=pyqm.translate("Control_pane_app_title"))
Label1.pack()
#Frame
frame=ctk.CTkFrame(main,width=300,height=350,fg_color=frame1_color)
frame.place(x=10,y=40)
frame2=ctk.CTkScrollableFrame(main,width=200,height=300,fg_color=frame2_color)
frame2.place(x=320,y=40)
#Frame1
label1=ctk.CTkLabel(frame,text=pyqm.translate("Settings"))
label1.place(x=110,y=0)
label2=ctk.CTkLabel(frame,text=pyqm.translate("Language"),font=("arial",11.3))
label2.place(x=10,y=30)
cbb=ctk.CTkComboBox(frame,values=value,fg_color="white",button_color=button_color,border_color=border_color,button_hover_color=button_hover_color,dropdown_fg_color=dropdown_fg_color,font=("arial",11.3))
cbb.place(x=100,y=30)
label3=ctk.CTkLabel(frame,text=pyqm.translate("Select_values_button"),font=("arial",11.3))
label3.place(x=10,y=70)
cbb1=ctk.CTkComboBox(frame,values=value1,fg_color="white",button_color=button_color,border_color=border_color,button_hover_color=button_hover_color,dropdown_fg_color=dropdown_fg_color,font=("arial",11.3))
cbb1.place(x=130,y=70)
check_update=ctk.CTkLabel(frame,text=pyqm.translate("check_update"),font=("arial",11.3))
check_update.place(x=10,y=110)
button=ctk.CTkButton(frame,fg_color=button_fg,hover_color=hover_color,text=pyqm.translate("check_update_button"))
button.place(x=10,y=140)
color_bt_lb=ctk.CTkLabel(frame,text=pyqm.translate("DEBUG_LB"),font=("arial",11.3))
color_bt_lb.place(x=10,y=170)
color_bt=ctk.CTkButton(frame,fg_color=button_fg,text=pyqm.translate("dev_button_DEBUG"),hover_color=hover_color,command=color_settings)
color_bt.place(x=10,y=200)
contact_lb=ctk.CTkLabel(frame,text=pyqm.translate("CONTACT"),font=("arial",11.3))
contact_lb.place(x=10,y=230)
link=ctk.CTkLabel(frame,text=pyqm.translate("Here"),text_color="yellow",font=("arial",11.3))
link.place(x=130,y=230)
link.bind("<Button-1>",contact)
reset_button=ctk.CTkButton(frame,text=pyqm.translate("reset_button"),command=reset,fg_color=button_fg,hover_color=hover_color)
reset_button.place(x=10,y=260)
buttonxacnhan=ctk.CTkButton(frame,fg_color=button_fg,text=pyqm.translate("confirm_button"),hover_color=hover_color,command=xacnhan)
buttonxacnhan.place(x=150,y=300)
#frame2
Label1=ctk.CTkLabel(frame2,text=pyqm.translate("Broad_exmampel"))
Label1.pack()
Label2=ctk.CTkLabel(frame2,text="________")
Label2.pack()
button_ex1=ctk.CTkButton(frame2,text="Button/Nút",fg_color=ex1)
button_ex1.pack()
lbex1=ctk.CTkLabel(frame2,text=pyqm.translate("Value_button1"))
lbex1.pack()
button_ex2=ctk.CTkButton(frame2,text="Button/Nút",fg_color=ex2,hover_color=ex2)
button_ex2.pack()
lbex2=ctk.CTkLabel(frame2,text=pyqm.translate("Value_button3"))
lbex2.pack()
button_ex3=ctk.CTkButton(frame2,text="Button/Nút",fg_color=ex3)
button_ex3.pack()
lbex3=ctk.CTkLabel(frame2,text=pyqm.translate("Value_button2"))
lbex3.pack()
Label6=ctk.CTkLabel(frame2,text="____________")
Label6.pack()
Label7=ctk.CTkLabel(frame2,text=pyqm.translate("version_broad"))
Label7.pack()
Label8=ctk.CTkLabel(frame2,text=pyqm.translate("VER"))
Label8.pack()
main.mainloop()