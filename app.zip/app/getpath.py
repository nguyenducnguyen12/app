import os
import json
def save_current_path():
    current_path = os.getcwd()
    data = {'path': current_path}
    with open('Resouces/path.json', 'w') as file:
        json.dump(data, file)
save_current_path()