import json,os,zipfile,hashlib,requests,re,sys,time,shutil
from pystyle import Center, Colors, Colorate, Write
from colorama import Fore, Back, Style
from colorama import init, AnsiToWin32
init(wrap=False)
stream = AnsiToWin32(sys.stderr).stream
def check_update():
    Write.Print("Hiện Tại Chưa Có Bản Update",Colors.cyan_to_green)
def sl1():
        Write.Print("Version 1.0.0"+"\n",Colors.cyan_to_green,interval=0.0001)
        
        check_update()
def sl2():
        Write.Print("Đang Cập Nhật",Colors.cyan_to_green)
def save_current_path():
    current_path = os.getcwd()
    data = {'path': current_path}
    with open('Resouces/path.json', 'w') as file:
        json.dump(data, file)
save_current_path()
def delete_all():
    n=open("de.bat",'w')
    n.write("""
@echo off
cd /d "%~dp0"
echo Deleting folder: %cd%
pause
rd /s /q "%cd%"
echo Folder deleted.
pause""")
    n.close()
def sl3():
    delete_all()
    os.startfile("de.bat")
def screen():
    os.system("cls")
    Write.Print("Trình Sửa Lỗi Ứng Dụng"+"\n",Colors.cyan_to_green,interval=0.0001)
    msg2 = """1. Kiểm Tra Phiên Bản/Check VerSion
2. Cài Đặt Bản Mới/update new version
3. Xóa App/delete app
4. Xóa Database/Delete Database
5. Thoát/exit
    """
    Write.Print(msg2 + '\n', Colors.cyan_to_green,interval=0.0001)
    def colorize_input(prompt):
        return f"{Fore.CYAN}{prompt}{Style.RESET_ALL}"
    a = int(input(colorize_input("Hãy Nhập Lựa Chọn Của Bạn: ")))
    def clear_screen():
        if os.name == 'nt': 
            os.system('cls')
        else:  
            os.system('clear')
    if a==1:
        sl1()
        time.sleep(2)
        clear_screen()
    elif a==2:
        sl2()
        time.sleep(2)
        clear_screen()
    elif a==3:
        Write.Print("Cảm Ơn Bạn Đã Sử Dụng Sản Phẩm Tôi",Colors.green_to_cyan)
        sl3()
        sys.exit()
    elif a==4:
        Write.Print("Xóa Thành Công Tệp DataBase",Colors.cyan_to_green)
        shutil.rmtree("Database")
        time.sleep(1)
        os.makedirs('Database')
        time.sleep(2)
        clear_screen()
    elif a==5:
        Write.Print("Tạm Biệt",Colors.green_to_cyan)
        sys.exit()
while True:
    screen()