import os,json,hashlib,shutil,zipfile,requests
def download():
    link_request="https://github.com//nguyenducnguyen12//quanlydoanvien"
    with open("Resouces\\path.json",'r') as f:
        cc=json.load(f)
    path=cc["path"]
    link_udt=requests.get(link_request)
    temp_zip_file = "temp.zip"
    with open(temp_zip_file, "wb") as file:
        file.write(link_udt.content)

# Giải nén file
    with zipfile.ZipFile(temp_zip_file, "r") as zip_ref:
        zip_ref.extractall(json.load(open(path))["path"])
