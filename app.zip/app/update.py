import os
import json
import requests
import shutil
import zipfile
def dowload(url, path):
    response = requests.get(url, stream=True)
    with open(path, 'wb') as file:
        shutil.copyfileobj(response.raw, file)
def extra(zip_path, extract_path):
    with zipfile.ZipFile(zip_path, 'r') as zip_ref:
        zip_ref.extractall(extract_path)
def main():
    url = 'https://github.com/nguyenducnguyen12/app/raw/main/app.zip'
    with open('resouces//path.json', 'r') as file:
        data = json.load(file)
    extract_path = data['path']
    zip_path = 'app.zip'
    dowload(url, zip_path)
    extra(zip_path, extract_path)
    os.remove(zip_path)
if __name__ == '__main__':
    main()